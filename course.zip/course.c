/**
 * @file course.c
 * @author Daniel Checchia (checchid@mcmaster.ca)
 * @date 2022-04-12
 * @brief Contains the fully done/defined Course Functions. (enroll_student, print_course,
 *        top_student and passing)
 * 
 */
#include "course.h"
#include <stdlib.h>
#include <stdio.h>

/** 
 * @brief Adds a student (with their information) to a course's array of students.
 * 
 * @param course a Course represented as a Course type pointer.
 * @param student a Student represented as a Student type pointer.
 * @return nothing
 */
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student)); // initializes the students array of a course by giving it some memory.
  }
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); // gives the students array of a course more memory to store exactly one more student.
  }
  course->students[course->total_students - 1] = *student;
}

/** 
 * @brief Prints the information of a course. (course name, course code, number of students, and every student (with their information) in the course)
 * 
 * @param course a Course represented as a Course type pointer.
 * @return nothing
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++) // prints every student (with their information) in the course
    print_student(&course->students[i]);
}

/** 
 * @brief finds the student in a course with the highest average.
 * 
 * @param course a Course represented as a Course type pointer.
 * @return The student (with all thier information) that has the highest average.
 */
Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 
  for (int i = 1; i < course->total_students; i++) //goes through the course's students array one by one to find the student with the highest average by comparing each students average to a "max_average", and setting that "max_average" to the students average, if the students average is greater than the "max_average".
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}

/** 
 * @brief Stores all the students (including all their information) of a course who are passing into an array, and Calculates the total number of passing students in a course.
 * 
 * @param course a Course represented as a Course type pointer.
 * @param total_passing passes an integer pointer into the function to store the number of passing students to be used later.
 * @return an array of all the students who are passing.
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  for (int i = 0; i < course->total_students; i++) //goes through the course's students array one by one to find if that student is passing. if they are you add 1 to the number of students passing, which is stored in the variable "count"
    if (average(&course->students[i]) >= 50) count++;
  
  passing = calloc(count, sizeof(Student)); // allocates the exact amount memory to store all the passing students in an array.

  int j = 0;
  for (int i = 0; i < course->total_students; i++) //stores all the students (and their information) into the dynamically stored array "passing" whih was given memory above.
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}
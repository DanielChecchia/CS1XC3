/**
 * @file course.h
 * @author Daniel Checchia (checchid@mcmaster.ca)
 * @date 2022-04-12
 * @brief course library for managing courses, including course type definition 
 *        and course function initializations such as enroll_student, print_course,
 *        top_student and passing.
 * 
 */
#include "student.h"
#include <stdbool.h>

/**
* @brief Course type stores a course with fields name, code, students, and total_students.
*
*/
typedef struct _course 
{
  char name[100]; /**< The course's name */ 
  char code[10]; /**< The course's course code */ 
  Student *students; /**< The course's students */ 
  int total_students; /**< The course's total number of students */ 
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);

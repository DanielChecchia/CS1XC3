/**
 * @mainpage Student and Course function demonstration
 * 
 * The Student and Course function demonstration shows how multiple functions in the Student and Course
 * library work, including:
 * - enrolling a student into a course
 * - generating a random student
 * - printing the information of a course
 * - finding the student in a course with the highest average (and printing their information)
 * - printing the total number of passing students in a course
 * - finding all the students in a course who are passing (and printing all of them, with their information)
 *  
 * @file main.c
 * @author Daniel Checchia (checchid@mcmaster.ca)
 * @date 2022-04-12
 * @brief Runs demonstration code for Student and Course methods.
 *  
 */
#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"


/**
 * @brief Creates a course full of students (Course and Student Type), and tests the Student/Course
 * library methods. 
 * 
 */
int main()
{
  srand((unsigned) time(NULL));

  Course *MATH101 = calloc(1, sizeof(Course)); //initializes a course by giving it the exact amount memory to store 1 course
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");

  for (int i = 0; i < 20; i++) // generates 20 random students, with 8 grades, and enrolls them into the course.
    enroll_student(MATH101, generate_random_student(8));
  
  print_course(MATH101);

  Student *student;
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student);

  int total_passing;
  Student *passing_students = passing(MATH101, &total_passing);
  printf("\nTotal passing: %d\n", total_passing); //uses the total_passing variable that was passed through and modified by the passing() function
  printf("\nPassing students:\n\n");
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]); // prints all the students (with their information) that are passing, in the course.
  
  return 0;
}
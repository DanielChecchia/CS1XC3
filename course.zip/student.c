/**
 * @file student.c
 * @author Daniel Checchia (checchid@mcmaster.ca)
 * @date 2022-04-12
 * @brief Contains the fully done/defined Student Functions. (add_grade, average, print_student and 
 *        generate_random_student)
 *
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"

/** 
 * @brief Adds a grade to a students array of grades.
 * 
 * @param student a Student represented as a Student type pointer.
 * @param grade a grade value represented as a Double.
 * @return nothing
 */
void add_grade(Student* student, double grade)
{
  student->num_grades++;
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double)); // initializes the grades array of a student by giving it some memory.
  {
    student->grades = 
      realloc(student->grades, sizeof(double) * student->num_grades); // gives the grades array of a student more memory to store exactly one more grade.
  }
  student->grades[student->num_grades - 1] = grade;
}

/** 
 * @brief calculates the average grade of a student.
 * 
 * @param student a Student represented as a Student type pointer.
 * @return The average grade of the student.
 */
double average(Student* student)
{
  if (student->num_grades == 0) return 0;

  double total = 0;
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i]; // adds all the grades of a student together, so thier average can be calculated by dividing this total by the number of grades the student has.
  return total / ((double) student->num_grades); 
}

/** 
 * @brief Prints the information of a student. (First name, Last name, Student id, grades, and the average of the grades)
 * 
 * @param student a Student represented as a Student type pointer.
 * @return nothing
 */
void print_student(Student* student)
{
  printf("Name: %s %s\n", student->first_name, student->last_name);
  printf("ID: %s\n", student->id);
  printf("Grades: ");
  for (int i = 0; i < student->num_grades; i++) // prints each grade that the student has
    printf("%.2f ", student->grades[i]);
  printf("\n");
  printf("Average: %.2f\n\n", average(student));
}

/** 
 * @brief Generates a random student from a predetermined array of first and last names.
 * 
 * @param grades The number of grades you want the student to have.
 * @return The random student.
 */
Student* generate_random_student(int grades)
{
  char first_names[][24] = // a predetermined list of first names.
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

  char last_names[][24] = // a predetermined list of last names.
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};
 
  Student *new_student = calloc(1, sizeof(Student)); // allocates the exact amount memory to store a student in order for it to be dynamically stored.

  strcpy(new_student->first_name, first_names[rand() % 24]);
  strcpy(new_student->last_name, last_names[rand() % 24]);

  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48); //generates a random student id number as a string
  new_student->id[10] = '\0'; //adds the required null terminator to the student id string

  for (int i = 0; i < grades; i++) //adds the specified number of random grades (between 25 and 100) to the student
  {
    add_grade(new_student, (double) (25 + (rand() % 75)));
  }

  return new_student;
}
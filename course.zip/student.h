/**
 * @file student.h
 * @author Daniel Checchia (checchid@mcmaster.ca)
 * @date 2022-04-12
 * @brief Student library for managing students, including Student type definition 
 *        and Student function initializations such as add_grade, average, 
 *        print_student and generate_random_student.
 * 
 */

/**
 * @brief Student type stores a student with fields first name, last name, id, grades and num_grades
 * 
 */
typedef struct _student 
{ 
  char first_name[50]; /**< The student's first name */ 
  char last_name[50]; /**< The student's last name */ 
  char id[11]; /**< The student's student id number */
  double *grades; /**< The student's grades */
  int num_grades; /**< The number of grades the student has */
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
